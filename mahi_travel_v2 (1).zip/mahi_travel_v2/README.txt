Mahi Travel v2 - includes manual OTP, user registration/login, demo wallet, and server1 mobile setting.

Import db_schema.sql and update config.php.
Admin default: admin/1234
OTP mode is manual by default.
